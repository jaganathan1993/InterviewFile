<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class subscribers extends Model
{
      protected $fillable=['id','Bookid','Userid'];
}
