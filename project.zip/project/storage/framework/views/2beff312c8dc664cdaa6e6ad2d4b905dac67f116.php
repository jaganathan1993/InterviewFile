
<?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title','User'); ?>

<?php $__env->startSection('content'); ?>

<br>
<!-- <?php echo e($userlist->id); ?> -->
<?php if(@session('response')): ?>
  <?php if(@session('response') == 'Subscribed Successfully' || @session('response') == 'Rejected Successfully'): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
  <?php else: ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
  <?php endif; ?>
  <strong><?php echo e(session('response')); ?></strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>

<?php ($j=0); ?>
  <?php $__currentLoopData = $bookscroll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($loop->index % 2 == 0): ?>

    <div class="row" style="background-color:#e6e6e6">
      <div id="multi-item-example<?php echo e($loop->index); ?>" class="carousel slide carousel-multi-item " data-ride="carousel" data-pause="hover" style="background-color:#e6e6e6">
    <?php else: ?>
      <div class="row" style="background-color:#cfe2e2">
      <div id="multi-item-example<?php echo e($loop->index); ?>" class="carousel slide carousel-multi-item " data-ride="carousel" data-pause="hover" style="background-color:#cfe2e2">
    <?php endif; ?>


  <div class="controls-top">

    <a class="btn-floating" href="#multi-item-example<?php echo e($loop->index); ?>" data-slide="prev"><i class="fas fa-chevron-left"></i></a>
    <span style="font-weight:bold;padding-left:40%;font-size:20px;position:absolute;"><?php echo e($val['category']); ?></span>
    <a class="btn-floating" href="#multi-item-example<?php echo e($loop->index); ?>" data-slide="next"><i class="fas fa-chevron-right" style="padding-left: 98%;position:absolute"></i></a>
  </div><br>
  <div class="carousel-inner" role="listbox">

      <?php ($count=0); ?>
      <?php $__currentLoopData = array_chunk($val['dataset'],4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fourRecord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($count == 0): ?>
          <div class="carousel-item active">
            <?php $__currentLoopData = $fourRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-3" style="float:left;font-size:12px;">
                 <div class="card" style="min-height:200px;">
                   <div  data-toggle="modal" data-target="#getBookDetails" style="cursor:pointer" data-cid="<?php echo e($b->id); ?>">
                   <div class="row">
                   <div class="col-md-6" >
                    <img class="card-img smallimg"
                      src="/Images/Book/<?php echo e($b->bImage); ?>" class="rounded mx-auto d-block" onerror="this.src='/Images/noimage.png'" alt="Card image cap" style="padding-top:10%">
                    </div>
                     <div class="col-md-6">
                       <h6 class="card-title"><?php echo e($b->bname); ?></h6>
                       <p class="card-text"><span class="fas fa-pencil-alt" style="padding-right:2%;color:#18a7bd"></span><?php echo e(Str::limit($b->author, 50)); ?></p>
                        <p class="card-text"><span class="fas fa-money-bill-alt" style="padding-right:2%;color:#18a7bd"></span><?php echo e(number_format($b->price,2)); ?></p>
                        <p class="card-text"><span class="fas fa-book-open"style="padding-right:2%;color:#18a7bd"></span><?php echo e(Str::limit($b->publisher, 50)); ?></p>
                    </div>
                  </div>
                </div>
                <?php if($b->subt == 0): ?>
                  <a href="<?php echo e(route('subscribeReq',['userid'=>$userlist['id'],'Bookid'=>$b->id])); ?>" class="btn btn-info form-control" style="position: absolute;bottom:   0;">Subscribe</a>
                  <?php else: ?>
                    <a href="<?php echo e(route('subscribeReqDelete',['userid'=>$userlist['id'],'Bookid'=>$b->id])); ?>" class="btn btn-danger form-control" style="position: absolute;bottom:0;">Reject</a>
                <?php endif; ?>
                </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php else: ?>
          <div class="carousel-item">
            <?php $__currentLoopData = $fourRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-3" style="float:left;font-size:12px;">
             <div class="card" style="min-height:200px;">
               <div  data-toggle="modal" data-target="#getBookDetails" style="cursor:pointer" data-cid="<?php echo e($b->id); ?>">
               <div class="row">
               <div class="col-md-6" >
                <img class="card-img smallimg"
                  src="/Images/Book/<?php echo e($b->bImage); ?>" class="rounded mx-auto d-block" onerror="this.src='/Images/noimage.png'" alt="Card image cap" style="padding-top:10%">
                </div>
                 <div class="col-md-6">
                   <h6 class="card-title"><?php echo e($b->bname); ?></h6>
                   <p class="card-text"><span class="fas fa-pencil-alt" style="padding-right:2%;color:#18a7bd"></span><?php echo e(Str::limit($b->author, 50)); ?></p>
                    <p class="card-text"><span class="fas fa-money-bill-alt" style="padding-right:2%;color:#18a7bd"></span><?php echo e(number_format($b->price,2)); ?></p>
                    <p class="card-text"><span class="fas fa-book-open"style="padding-right:2%;color:#18a7bd"></span><?php echo e(Str::limit($b->publisher, 50)); ?></p>
                </div>
              </div>
            </div>
            <?php if($b->subt == 0): ?>
              <a href="<?php echo e(route('subscribeReq',['userid'=>$userlist['id'],'Bookid'=>$b->id])); ?>" class="btn btn-info form-control" style="position: absolute;bottom:   0;">Subscribe</a>
              <?php else: ?>
                <a href="<?php echo e(route('subscribeReqDelete',['userid'=>$userlist['id'],'Bookid'=>$b->id])); ?>" class="btn btn-danger form-control" style="position: absolute;bottom:0;">Reject</a>
            <?php endif; ?>
            </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>

        <?php ($count++); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<br>
</div>
<br>
    <?php ($j++); ?>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <div class="modal fade" id="getBookDetails">
     <div class="modal-dialog modal-lg">
       <div class="modal-content">

         <!-- Modal Header -->
         <div class="modal-header">
           <h5 class="modal-title">Book Details</h5>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
         </div>

         <!-- Modal body -->
         <div class="modal-body">
           <h5 id="id" style="text-align:center;color:#17a2b8"></h5><br>
           <div class="row">

             <div class="col-md-6">

               <img class="card-img smallimg"
                 id="previewimage" onerror="this.src='/Images/noimage.png'" alt="Card image cap" style="padding-top:10%">
            </div>
            <div class="col-md-6">
              <div class="card">
             <ul class="list-group list-group-flush" style="font-size:12px;">
               <b style="background-color:#17a2b8;color:white;padding-left:5%;">Author:</b><li class="list-group-item" id="author"></li>
             </ul><br>
             <ul class="list-group list-group-flush" style="font-size:12px;">
               <b style="background-color:#17a2b8;color:white;padding-left:5%;">Publisher:</b><li class="list-group-item" id="publisher"></li>
             </ul><br>
             <ul class="list-group list-group-flush" style="font-size:12px;">
                <b style="background-color:#17a2b8;color:white;padding-left:5%;">Category:</b><li class="list-group-item" id="category"></li>
              </ul><br>
              <ul class="list-group list-group-flush" style="font-size:12px;">
                 <b style="background-color:#17a2b8;color:white;padding-left:5%;">Description:</b><li class="list-group-item" id="description"></li>
               </ul>

           </div>
           </div>
         </div>
         </div>

         <!-- Modal footer -->
         <div class="modal-footer">
           <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
         </div>

       </div>
     </div>
   </div>

<!--/.Carousel Wrapper-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\project\resources\views/pages/showuser.blade.php ENDPATH**/ ?>